<div class="four columns">

	<div class="widget">
		<h5>Suscribite</h5>
		<form action="app/suscribite.php" method="POST">
			<label for="email">Tu Email</label>
			<input name="email" class="u-full-width" type="email" placeholder="test@mailbox.com">
			<input class="button-primary" type="submit" value="Suscribime maquina">
		</form>
	</div>

	<div class="widget">
		<h5>Widget</h5>
		<ul>
			<li></li>
		</ul>
	</div>

</div>