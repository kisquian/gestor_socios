<!-- Static navbar -->
      <div id="navarea">
        <nav class="navbar navbar-default" role="navigation">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>             
            </div>
			
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav custom_nav">
                 <li class="dropdown">
                  <a href="#" class="" data-toggle="dropdown" role="button" aria-expanded="false">Noticias</a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="archive1.html">Deportes</a></li>
                    <li><a href="archive1.html">Educacion</a></li>
                    <li><a href="archive1.html">Politica</a></li>
                    <li><a href="archive1.html">Actualidad</a></li>                
                  </ul>
                </li>            
                <li><a href="single.html">Guía comercial</a></li>
                <li><a href="archive1.html">Servicios</a></li>
                <li><a href="archive1.html">Buscar trabajo</a></li>
              </ul>           
            </div><!--/.nav-collapse -->
			
          </div><!--/.container-fluid -->
        </nav>
      </div>