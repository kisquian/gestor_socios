<!-- start site main content -->
      <section id="mainContent">
        <!-- start main content top -->
        <div class="content_top">
          <div class="row">
             <!-- start content top latest slider -->
            <div class="col-lg-6 col-md-6 col-sm6">             
              <div class="latest_slider">
                 <!-- Set up your HTML -->
                <div class="slick_slider">
                  <div class="single_iteam">
                    <img src="img/1.jpg" alt="img">
                    <h2><a class="slider_tittle" href="single.html">Polémicas elecciones en el Club Atletico Cerro</a></h2>
                  </div>
                  <div class="single_iteam">
                    <img src="img/2.jpg" alt="img">
                    <h2><a class="slider_tittle" href="single.html">Rampla se reinventa</a></h2>
                  </div>
                  <div class="single_iteam">
                    <img src="img/3.jpg" alt="img">
                     <h2><a class="slider_tittle" href="single.html">Comenzaron las obras en la teja</a></h2>
                  </div>
                  
                </div>
              </div>
            </div> <!-- End content top latest slider -->

            <div class="col-lg-6 col-md-6 col-sm6 smallNews">
              <div class="content_top_right">
                <ul class="featured_nav wow fadeInDown">
                  <li>
                    <img src="img/devhill/300x215x1.jpg" alt="img">
                    <div class="title_caption">
                      <a href="single.html">
                        Esta es la otra cara del barrio Tobogan
                      </a>
                    </div>
                  </li>
                  <li>
                    <img src="img/devhill/300x215x2.jpg" alt="img">
                    <div class="title_caption">
                      <a href="single.html">
                        Joven Karateca trajo la medalla de bronce al Cerro
                      </a>
                    </div>
                  </li>
                   <li>
                    <img src="img/devhill/300x215x3.jpg" alt="img">
                    <div class="title_caption">
                      <a href="single.html">
                        Coetc: Bienvenida al Cerro de Montevideo
                      </a>
                    </div>
                  </li>
                   <li>
                    <img src="img/devhill/300x215x4.jpg" alt="img">
                    <div class="title_caption">
                      <a href="single.html">
                        El liceo 11 es reconocido como el "mas completo del país"
                      </a>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div><!-- End main content top -->