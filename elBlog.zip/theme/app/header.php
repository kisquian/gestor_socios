<!-- start header area -->
    <header id="header">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <!-- start header top -->
          <div class="header_top">
            <div class="header_top_left">
              <ul class="top_nav">
                <li><a href="index.html">Inicio</a></li>
                <li><a href="page.html">Publique gratis</a></li>
                <li><a href="contact.html">Contacto</a></li>
              </ul>
            </div>
          </div><!-- End header top -->
          <!-- start header bottom -->
          <div class="header_bottom">
            <div class="header_bottom_left">
            <!-- for img logo -->
			
            <!-- <a class="logo" href="index.html">
              <img src="img/logo.jpg" alt="logo">
             </a>-->
             <!-- for text logo -->
              <a class="logo" href="index.html">
               PORTAL DEL <strong>CERRO</strong> <span>Toda la información en la web del barrio</span>
             </a> 
			 
            </div>
            <div class="header_bottom_right">
              <!-- <a href="http://wpfreeware.com"><img src="img/addbanner_728x90_V1.jpg" alt="img"></a> -->
            </div>
          </div><!-- End header bottom -->
        </div>
      </div>
    </header><!-- End header area -->