<footer id="footer">
      <div class="footer_top">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="single_footer_top wow fadeInLeft">
                <h2>Flicker Images</h2>
                <ul class="flicker_nav">
                  <li>
                      <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>                 
                  <li>
                      <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>
                   <li>
                      <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>                 
                  <li>
                      <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>
                   <li>
                      <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>                 
                  <li>
                     <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>
                   <li>
                      <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>                 
                  <li>
                     <a href="#"><img src="img/devhill/75x75.jpg" alt="img"></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="single_footer_top wow fadeInDown">
                <h2>Labels</h2>
                <ul class="labels_nav">
                  <li><a href="#">Gallery</a></li>
                  <li><a href="#">Business</a></li>
                  <li><a href="#">Games</a></li>
                  <li><a href="#">Fashion</a></li>
                  <li><a href="#">Sports</a></li>
                  <li><a href="#">Technology</a></li>
                  <li><a href="#">Slider</a></li>
                  <li><a href="#">Life & Style</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="single_footer_top wow fadeInRight">
                <h2>About Us</h2>
                <p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed nec laoreet orci, eget ullamcorper quam. Phasellus lorem neque, </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer_bottom">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="footer_bottom_left">
                <p>Copyright © 2017 <span>portaldelcerro.com</span></p>
              </div>   
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="footer_bottom_right">
                <p>Creado por <a href="http://cosmicoweb.com/">Cosmico</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>