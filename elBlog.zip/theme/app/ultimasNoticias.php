<!-- start single bottom rightbar -->
                <div class="single_bottom_rightbar">
                  <h2>Últimas noticias</h2>
                  <ul class="small_catg popular_catg wow fadeInDown">
                    <li>
                      <div class="media wow fadeInDown">
                        <a href="#" class="media-left">
                          <img alt="img" src="img/devhill/112x112.jpg">
                        </a>
                        <div class="media-body">
                          <h4 class="media-heading"><a href="#">Duis condimentum nunc pretium lobortis </a></h4> 
                          <p>Nunc tincidunt, elit non cursus euismod, lacus augue ornare metus, egestas imperdiet nulla nisl quis mauris. Suspendisse a pharetra </p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="media wow fadeInDown">
                        <a href="#" class="media-left">
                          <img alt="img" src="img/devhill/112x112.jpg">
                        </a>
                        <div class="media-body">
                          <h4 class="media-heading"><a href="#">Duis condimentum nunc pretium lobortis </a></h4> 
                         <p>Nunc tincidunt, elit non cursus euismod, lacus augue ornare metus, egestas imperdiet nulla nisl quis mauris. Suspendisse a pharetra </p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="media wow fadeInDown">
                        <a href="#" class="media-left">
                          <img alt="img" src="img/devhill/112x112.jpg">
                        </a>
                        <div class="media-body">
                          <h4 class="media-heading"><a href="#">Duis condimentum nunc pretium lobortis </a></h4> 
                          <p>Nunc tincidunt, elit non cursus euismod, lacus augue ornare metus, egestas imperdiet nulla nisl quis mauris. Suspendisse a pharetra </p>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div> <!-- End single bottom rightbar -->