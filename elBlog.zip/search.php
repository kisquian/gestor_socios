<?php
  include_once('inc/includes.php');

  // Listado de usuarios
  $post = new Post();

  include_once('app/views/search_post.php');